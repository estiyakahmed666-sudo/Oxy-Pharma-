Oxy Pharma and departmental store — Android project

This is an Android Studio project source, not a compiled APK.

How to build:
1. On a computer, install Android Studio.
2. Extract this ZIP.
3. Android Studio > Open, select the extracted OxyPharmaDuty folder.
4. Wait for Gradle sync to finish (internet may be needed for first setup).
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When finished, use the "locate" link in Android Studio to find app-debug.apk.
7. Transfer the APK to your Android phone and install it. Android may ask you to allow installs from that source.

App name: Oxy Pharma and departmental store
Package: com.oxypharma.duty

Notes:
- This project wraps the existing offline duty calculator in an Android WebView.
- The calculator stores records in local browser storage within the app.
- I could not compile an APK in this environment because Android SDK/Gradle are not installed.
